import os
import asyncio
from playwright.async_api import async_playwright
from flask import Flask, render_template, request

app = Flask(__name__)

# Register custom URL schemes
# e.g., flag{dummyflag} -> f1://ctf, l2://ctf, a3://ctf, g4://ctf, etc.
##################################################

FLAG = os.environ.get("FLAG", "flag{dummyflag}").lower()

assert len(FLAG) <= 27, "Invalid flag format"
assert FLAG.startswith("flag{") and FLAG.endswith("}"), "Invalid flag format"
assert FLAG[6:-1].replace("_", "").isalpha(), "Invalid flag format"


def register_scheme(letter, index):
    scheme = f"{letter}{index}"
    desktop_entry = f"""
[Desktop Entry]
Name={scheme} URL Handler
Exec=echo "{scheme}://ctf"
Type=Application
NoDisplay=true
MimeType=x-scheme-handler/{scheme};
"""
    desktop_file_path = os.path.expanduser(f"~/.local/share/applications/")
    os.makedirs(desktop_file_path, exist_ok=True)
    with open(
        f"{desktop_file_path}/{scheme}_url_handler.desktop", "w+"
    ) as desktop_file:
        desktop_file.write(desktop_entry)
    os.system("update-desktop-database ~/.local/share/applications")


for index, letter in enumerate(FLAG, start=1):
    register_scheme(letter, index)

##################################################


@app.route("/", methods=["GET"])
def index_get():
    return render_template("index_get.html")


async def crawl(url):
    async with async_playwright() as p:
        browser = await p.firefox.launch()
        context = await browser.new_context(
            accept_downloads=False, java_script_enabled=False, service_workers="block"
        )
        page = await context.new_page()

        try:
            if url.startswith(f"http://") or url.startswith(f"https://"):
                await page.goto(url, timeout=5000)
        except:
            pass

        await browser.close()


@app.route("/", methods=["POST"])
def index_post():
    asyncio.run(crawl(request.form.get("url")))
    return render_template("index_post.html")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=31415)

import os
import jwt
import random
from flask import Flask, jsonify, request, make_response, render_template


app = Flask(__name__)

FLAG = os.environ.get("FLAG", "flag{*****REDACTED*****}")


def determine_status(balance):
    status = FLAG
    if balance > 0:
        status = "rich"
    if balance <= 0:
        status = "poor"
    return f"You are a {status} person, aren't you?"


# omg ;(
KEY = str(random.randint(1, 10**6))


def encode_jwt(balance):
    payload = {"balance": balance}
    return jwt.encode(payload, KEY, algorithm="HS256")


def decode_jwt(token):
    try:
        payload = jwt.decode(token, KEY, algorithms="HS256")
        return payload.get("balance")
    except:
        return None


@app.route("/")
def index():
    token = request.cookies.get("account")
    if token:
        balance = decode_jwt(token)
        if balance is not None:
            status = determine_status(balance)
            return render_template("index.html", balance=balance, status=status)
    resp = make_response(
        render_template(
            "index.html",
            balance=1000,
            status="Welcome! Setting your initial balance to $1000.",
        )
    )
    resp.set_cookie("account", encode_jwt(1000))
    return resp


@app.route("/transaction", methods=["POST"])
def transaction():
    data = request.get_json()
    if "amount" in data and isinstance(data["amount"], int):
        amount = data["amount"]
        token = request.cookies.get("account")
        balance = decode_jwt(token)
        if balance is not None:
            balance += amount
            status = determine_status(balance)
            new_token = encode_jwt(balance)
            resp = jsonify({"balance": balance, "status": status})
            resp.set_cookie("account", new_token)
            return resp
        else:
            return jsonify({"error": "Invalid token."}), 400
    else:
        return (
            jsonify({"error": "Invalid amount specified. Amount must be an integer."}),
            400,
        )


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=4445)

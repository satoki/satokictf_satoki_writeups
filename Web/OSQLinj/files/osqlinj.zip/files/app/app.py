import os
import re
import osquery
import secrets
from flask import Flask, request, session, abort, redirect, url_for, render_template

app = Flask(__name__)
app.config["SECRET_KEY"] = secrets.token_hex(16)

FLAG = "flag_a~genai"

with open("flag.txt", "r+") as file:
    FLAG = file.read()
    file.seek(0)
    file.write(":(")
    file.truncate()


@app.route("/register", methods=["GET", "POST"])
def register():
    username = request.form.get("username")
    password = request.form.get("password")
    if username:
        username = re.sub("[^a-zA-Z0-9]", "", username)[:32]
        password = re.sub("[^a-zA-Z0-9]", "", password)[:32]
        if "admin" in username:
            return abort(403, "Hahaha, nice try!")
        session["username"] = username
        os.makedirs(f"users/{username}", exist_ok=True)
        with open(f"users/{username}/{password}", "w") as file:
            file.write(":)")
        return redirect(url_for("login"))
    else:
        return render_template("register.html")


@app.route("/", methods=["GET", "POST"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    if username:
        instance = osquery.SpawnInstance()
        instance.open()
        response = instance.client.query(
            f"SELECT count(*) FROM file WHERE directory = 'users/{username}' AND filename = '{password}'"
        )
        if response.status.message == "OK":
            count = int(response.response[0]["count(*)"])
            if count == 1:
                session["username"] = username
                del instance
                if session["username"] == "admin" and request.remote_addr.startswith(
                    "172."
                ):
                    return render_template(
                        "dashboard.html",
                        username=session["username"],
                        flag=FLAG,
                    )

                else:
                    return render_template(
                        "dashboard.html", username=session["username"], flag=":)"
                    )
        del instance
        return abort(401)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=4649)

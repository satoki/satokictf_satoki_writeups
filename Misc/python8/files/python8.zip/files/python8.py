#!/usr/local/bin/python

print(
    """\
Python 8.26.1997 (main, Aug 26 2997, 00:00:00) [SatoCompiler 1.0.0] on linux
Type "help", "copyright", "credits" or "license" for more information."""
)

while True:
    code = input(">>> ")
    if code == "exit()":
        break
    if code in ["help", "copyright", "credits", "license"]:
        print(":)")
        continue
    for c in code:
        if c not in "0'()%cex":
            print(
                f"""\
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
SatokiError: character '{c}' is not allowed"""
            )
            break
    else:
        exec(code)
